"""Internal implementation package for the PyMotion Lite SDK.

User programs must use ``import pymotion as pm`` and ``pm.lite``.  Transport,
protocol, parser, and firmware-compatibility modules below this package are
private implementation details and are intentionally not re-exported here.
"""

__version__ = "1.0.1"

__all__: list[str] = []
